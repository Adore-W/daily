package com.example.springboot01;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/hello")
public class MySpringBoot {
    @GetMapping("/{id}")
    public String getByID(@PathVariable String id) {
        System.out.println("hello"+id);
        return "hell wzc";
    }
}

