package com.example.springboot02;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;
@Data
@Component
@ConfigurationProperties(prefix = "enterprise")
public class Ent{
    private String name;
    private Integer age;
    private Integer tel;
    private String[] subject;
}