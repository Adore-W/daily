package com.example.springboot02;

import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/hello")
public class MyController {
    //三层级 @Value直接读取
    @Value("${lesson}")
    private String lesson1;
    @Value("${enterprise.name}")
    private String name1;
    @Value("${enterprise.subject[0]}")
    private String sub1;

    //Environment 封装后读取
    @Autowired
    private Environment env;

    //实体类封装属性
    @Autowired
    private Ent ent;


    @RequestMapping("/wzc")
    public  String getById() {
        System.out.println("一级属课程："+lesson1);
        System.out.println("二级属姓名:"+name1);
        System.out.println("三级属学科:"+sub1);

        System.out.println("Environment封装后读取姓名："+env.getProperty("enterprise.name"));

        System.out.println("实体类封装属性读取号码："+ent.getName());
        return "hello";
    }
}

