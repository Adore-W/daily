package wzc.dao;

public interface BookAdd {
    public void add();
    public void del();
    public void change();
    public void check();
}
