package wzc.dao;

public class BookAddImpl implements BookAdd {
    public void add(){
        System.out.println("图书增加完成");
    }
    public void del(){
        System.out.println("图书减少完成");
    }
    public void change(){
        System.out.println("图书改变完成");
    }
    public void check(){
        System.out.println("图书查找完成");
    }
}
