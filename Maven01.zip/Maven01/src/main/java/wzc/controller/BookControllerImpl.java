package wzc.controller;

import wzc.service.BookServe;

public class BookControllerImpl implements BookController {
    private BookServe bookServe;
    public void setBookServe(BookServe bookServe) {
        this.bookServe = bookServe;
    }
    public void say() {
        this.bookServe.say();
        System.out.println("Controller类调用service类");
    }
}
