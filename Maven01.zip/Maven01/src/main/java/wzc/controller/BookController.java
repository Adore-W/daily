package wzc.controller;

public interface BookController {
    public void say();
}
