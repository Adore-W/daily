package wzc.service;

import wzc.dao.BookAdd;

public class BookServeImpl implements BookServe {
    private BookAdd bookAdd;
    public void setBookAdd(BookAdd bookAdd) {
        this.bookAdd = bookAdd;
    }
    public void say(){
        this.bookAdd.add();
        this.bookAdd.del();
        this.bookAdd.change();
        this.bookAdd.check();
        System.out.println("service类调用dao类");
    }
}
