package wzc.service;

public interface BookServe {
    public void say();
}
