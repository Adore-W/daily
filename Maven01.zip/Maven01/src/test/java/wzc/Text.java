package wzc;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import wzc.controller.BookController;
import wzc.dao.BookAdd;
import wzc.service.BookServe;

public class Text {
    public static void main(String[] args) {
        ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
        new ClassPathXmlApplicationContext("applicationContext.xml");
//        BookAdd bookAdd = (BookAdd) context.getBean("bookAdd");
//        bookAdd.say();
//        BookServe userServe = (BookServe) context.getBean("userServe");
//        userServe.say();
        BookController bookController = (BookController) context.getBean("bookController");
        BookAdd bookAdd = (BookAdd) context.getBean("bookAdd");
        bookController.say();
    }
}
